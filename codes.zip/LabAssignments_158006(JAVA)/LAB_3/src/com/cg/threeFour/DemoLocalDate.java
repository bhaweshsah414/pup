package com.cg.threeFour;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class DemoLocalDate {
	public void localdate(){
	DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
	System.out.println("Enter Two date in dd-MM-yyyy format");
	Scanner sc= new Scanner(System.in);
	String dateString1=sc.next();
	String dateString2=sc.next();
	 LocalDate localdate1 = LocalDate.parse(dateString1, formatter);
	 LocalDate localdate2= LocalDate.parse(dateString2, formatter);
	 System.out.println("Duration between dates:");
	
	Period period =Period.between(localdate1, localdate2);

	 System.out.println("Day:"+Math.abs(period.getDays())+" Month:"+Math.abs(period.getMonths())+" year:"+Math.abs(period.getYears()));
	 }
	
	 

	public static void main(String[] args) {
	DemoLocalDate date=new DemoLocalDate();
date.localdate();
}
}

