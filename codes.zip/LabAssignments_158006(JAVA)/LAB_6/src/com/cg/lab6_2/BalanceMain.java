package com.cg.lab6_2;

	public class BalanceMain {
		public static void main(String[] args) {
			Person p1=new Person();
			Person p2 = new Person();
			p1.setName("Smith");
			p1.setAge(10);
			p1.getName();
			p1.getAge();
			System.out.println(p1.getName());
			Account a1 = new Account();
			a1.setBalance(2000);
			Account a2 = new Account();
			a2.setBalance(3000);
			a1.deposit(2000);
			a2.withdraw(2000);
			System.out.println(a1);
			System.out.println(a2);
		}

	}


