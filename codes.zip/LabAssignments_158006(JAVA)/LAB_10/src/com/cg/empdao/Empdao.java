package com.cg.empdao;


import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;



import com.cg.exception.EmployeeException;
import com.cg.lab10.DatabaseConnection;
import com.cg.lab10.Employee;


public class Empdao implements IEmpdao {
	  Connection connection;
    public Empdao(){
    	connection=DatabaseConnection.getConnection();
    }
    public  Employee addEmployee(Employee employee) throws EmployeeException {
		String sql="insert into employee"+"(empid,ename,salary,gender,insurancescheme)"+"values(?,?,?,?,?)";
		try {
			
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setInt(1,employee.getEmpid());
			ps.setString(2,employee.getName());
			
			ps.setDouble(3,employee.getSalary());
			ps.setString(4, employee.getGender());
			ps.setString(5, employee.getInsurancescheme());
			//Date sqlDate=Date.valueOf(student.getEnrollDate());
			//ps.setDate(5,sqlDate);
			//ps.executeUpdate();
			//student.setStudentCode(code);
			//int row=ps.executeUpdate();
			//System.out.println(row+"inserted");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
				if(e.getErrorCode()==1){
					throw new EmployeeException("empid already exists ");
				}
				else if(e.getErrorCode()==2291){
					throw new EmployeeException("Invalid emp code!!");
				}
				else{
					throw new EmployeeException(e.getMessage());
				}
		}
		return employee;
		
	}
    
	

}
